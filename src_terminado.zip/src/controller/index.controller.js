import { pool } from "../db.js";


export const getIndex =(req,res) => res.send('SELECT  * FROM LIC_TEMP')

